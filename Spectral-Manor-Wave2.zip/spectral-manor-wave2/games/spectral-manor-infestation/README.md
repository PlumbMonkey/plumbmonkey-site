Spectral Manor Infestation (Starter)
