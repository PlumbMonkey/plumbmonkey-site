Spectral Manor Soul Circuit
