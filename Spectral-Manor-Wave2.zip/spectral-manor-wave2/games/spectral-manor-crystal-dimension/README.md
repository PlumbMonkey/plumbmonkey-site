Spectral Manor Crystal Dimension
