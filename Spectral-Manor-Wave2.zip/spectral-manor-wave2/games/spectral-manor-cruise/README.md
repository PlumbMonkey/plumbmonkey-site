Spectral Manor Cruise (Starter)
