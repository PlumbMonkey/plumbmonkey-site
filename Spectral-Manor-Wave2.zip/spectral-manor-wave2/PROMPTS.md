# Grok Build Prompts — Spectral Manor Wave 2

Copy any of these directly into Grok Build (VS Code) while the matching game folder is open.

---

## 1. Spectral Manor Soul Circuit (highest priority)

```
You are building Spectral Manor Soul Circuit — a Pac-Man style game for the Ghost Circuit / Plumbmonkey Media universe.

Theme: The hero travels through a hedge maze on the Spectral Manor grounds collecting crystals. Four classic monsters chase him: Vampire, Frankenstein, Werewolf, and Witch. Large power crystals give the hero a temporary magic field. While the field is active, touching an enemy forces that enemy to respawn (like a power pellet).

Requirements:
- Pure HTML5 Canvas + JavaScript (index.html + game.js)
- 960×540 canvas
- Hedge maze (tile-based or wall-based) that looks like a dark Victorian garden maze
- Player moves with WASD / Arrows
- Small glowing crystals to collect for points
- Large power crystals that activate a glowing magic field for ~8–10 seconds
- While magic field is active: player glows purple/cyan, enemies that touch the player are forced to respawn at their start points and give bonus points
- Four distinct monsters with different colors and slight AI differences:
  - Vampire (fast, red/black)
  - Frankenstein (slow, tanky, green)
  - Werewolf (medium, aggressive, grey/brown)
  - Witch (medium, purple, can “blink” short distances occasionally)
- Score, lives, level / wave, crystals remaining
- Simple Web Audio SFX (collect, power-up, death, enemy respawn)
- Ghost Circuit visual style: dark purple/black background, glowing purple/cyan accents, elegant but readable
- Title screen and game-over overlay
- Keep code clean and well-commented

Make it immediately fun and on-brand. Start with a solid playable maze.
```

---

## 2. Spectral Manor Crystal Dimension

```
You are building Spectral Manor Crystal Dimension — an Asteroids-style game for Ghost Circuit.

Theme: A parallel dimension where gravity has failed. The player pilots a small spectral ship. Giant rocks drift and can crush you. Enemy space ghosts pilot spectral ships and try to destroy you. Crystals float for score and power.

Requirements:
- Pure HTML5 Canvas + JavaScript
- 960×540 canvas
- Classic Asteroids controls: rotate left/right, thrust, shoot
- Player ship with Ghost Circuit neon look
- Asteroids / rocks of 3 sizes that break into smaller pieces when shot
- Rocks can crush the player on contact
- Enemy “Space Ghosts” in small spectral ships that move, occasionally shoot, and can ram
- Floating crystals that give points / temporary power
- Screen wrap
- Score, lives, wave
- Particle explosions, engine trail, neon lasers
- Web Audio SFX
- Dark cosmic background with purple nebula / stars
- Title and game-over screens

Keep the feel of classic Asteroids but make it distinctly Ghost Circuit / Spectral Manor.
```

---

## 3. Spectral Manor Cruise

```
You are building Spectral Manor Cruise — a Cruisin’ USA / OutRun style racing game for Ghost Circuit.

Theme: Race at night through haunted roads around Spectral Manor. Your opponents are the four classic monsters: Vampire (sleek black car), Frankenstein (heavy green truck), Werewolf (ragged grey vehicle), Witch (purple floating/hover car).

Requirements:
- Pure HTML5 Canvas + JavaScript
- Pseudo-3D road (classic OutRun / Cruisin’ style road projection) or simplified top-down racer if 3D road is too heavy
- Player car with Ghost Circuit purple neon
- Four AI opponents with distinct personalities and vehicles
- Roadside scenery: manor silhouette, trees, fog, glowing windows, tombstones, etc.
- Speed, position, lap or checkpoint system
- Simple collision / bumping
- Night-to-storm visual progression optional
- Score / time / place
- Web Audio engine + crash SFX

Start with a fun, readable pseudo-3D road or clean top-down if needed for speed.
```

---

## 4. Spectral Manor Infestation

```
You are building Spectral Manor Infestation — a Centipede-style game for Ghost Circuit.

Theme: The manor gardens and cemetery are overrun by haunted spectral bugs. A long segmented “Hauntipede” (and smaller bugs) move in classic Centipede patterns. The player shoots from the bottom of the screen.

Requirements:
- Pure HTML5 Canvas + JavaScript
- Classic Centipede movement (sideways + drop a row when hitting edge or obstacle)
- Segmented Hauntipede that splits when shot
- Smaller haunted bugs / spiders / fleas as extra enemies
- Mushrooms replaced by haunted toadstools or crystal growths that can be shot
- Player at bottom, moves left/right, shoots upward
- Ghost Circuit palette (purple, cyan, magenta, dark greens)
- Score, lives, wave
- Particle effects when segments die
- Web Audio SFX

Make the bugs feel spectral and creepy while keeping classic Centipede gameplay tight and fun.
```

---

## Usage Notes
- Open the target game folder in VS Code
- Paste the matching prompt into Grok Build
- After it generates, test with Live Server
- Ask for specific polish (better art, more AI, particles, etc.) in follow-up prompts
