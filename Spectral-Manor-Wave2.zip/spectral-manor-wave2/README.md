# Spectral Manor Arcade — Wave 2

**Plumbmonkey Media · Ghost Circuit**  
Isolated package — does **not** overwrite your updated Wave 1 builds.

## Full Series Branding

### Wave 1 (your local updated builds)
1. **Spectral Manor Revenger** — Defender style
2. **Spectral Manor Mess Hall** — Food Fight style
3. **Spectral Manor Swarm** — Robotron style
4. **Spectral Manor: Luno’s Flight** — Joust style (ride Luno)

### Wave 2 (this package)
5. **Spectral Manor Cruise** — Cruisin’ style racing (Vampire / Frankenstein / Werewolf / Witch opponents)
6. **Spectral Manor Crystal Dimension** — Asteroids / zero-G (flying rocks + space ghosts)
7. **Spectral Manor Infestation** — Centipede style (haunted bugs)
8. **Spectral Manor Soul Circuit** — Pac-Man style (hedge maze, crystals, magic discharge)

## Folder Structure
```
spectral-manor-wave2/
├── index.html                          ← Wave 2 Game Room / Arcade lobby
├── README.md                           ← This file
├── PROMPTS.md                          ← Ready-to-paste Grok Build prompts
└── games/
    ├── spectral-manor-soul-circuit/    ← Full playable prototype
    ├── spectral-manor-crystal-dimension/ ← Full playable prototype
    ├── spectral-manor-cruise/          ← Solid starter + notes
    └── spectral-manor-infestation/     ← Solid starter + notes
```

## How to Run Locally
```bash
# From the spectral-manor-wave2 folder
npx serve .
# or open index.html with VS Code Live Server
```

Then click any game card.

## How to Resume If We Get Stalled (New Chat Instructions)

Copy-paste this into a new Grok chat:

---

**Resume prompt for new chat:**

```
I am continuing the Spectral Manor Arcade project with Plumbmonkey Media / Ghost Circuit.

Wave 1 (already done, do not overwrite):
- Spectral Manor Revenger
- Spectral Manor Mess Hall
- Spectral Manor Swarm
- Spectral Manor: Luno’s Flight

Wave 2 (current focus — isolated package):
- Spectral Manor Cruise (Cruisin’ – race vs Vampire, Frankenstein, Werewolf, Witch)
- Spectral Manor Crystal Dimension (Asteroids / zero-G, flying rocks that crush, space ghosts in ships)
- Spectral Manor Infestation (Centipede – haunted bugs)
- Spectral Manor Soul Circuit (Pac-Man – hedge maze, collect crystals, 4 monsters chase, power crystals give magic field that forces enemies to respawn on touch)

The package lives at:
/home/workdir/artifacts/spectral-manor-wave2/

Please read the README.md and PROMPTS.md inside that folder, then continue from where we left off.
```

---

## GitHub Pages
Upload the contents of `spectral-manor-wave2/` to a new repo or put it under `/arcade-wave2/` on your main site.

## Author
William "Plumbmonkey" Henwood · Plumbmonkey Media  
Alberta, Canada · Ghost Circuit universe
