# Spectral Manor Arcade

**Ghost Circuit** arcade series by Plumbmonkey Media  
Four classic games reborn in the haunted manor.

## Games

| Game | Style | Path |
|------|--------|------|
| Spectral Manor Revenger | Defender | `/games/spectral-manor-revenger/` |
| Spectral Food Fight | Food Fight | `/games/spectral-food-fight/` |
| Spectral Robotron | Robotron | `/games/spectral-robotron/` |
| Spectral Skyline | Joust (ride Luno) | `/games/spectral-skyline/` |

## Deploy on GitHub Pages (tonight)

### Option A — Dedicated repo (recommended, cleanest)

1. Create a new public repo: `spectral-manor-arcade` (or `plumbmonkey-arcade`)
2. Upload **everything** in this folder to the root of that repo
3. GitHub → **Settings** → **Pages**
4. Source: **Deploy from a branch** → `main` → `/ (root)`
5. Save

Live URL will be:
```
https://plumbmonkey.github.io/spectral-manor-arcade/
```
(or `https://YOUR_USERNAME.github.io/REPO_NAME/`)

### Option B — Inside plumbmonkey-site

1. Copy this whole folder into your site repo as:
   ```
   plumbmonkey-site/public/arcade/
   ```
   or
   ```
   plumbmonkey-site/arcade/
   ```
2. Push to GitHub
3. If the site already uses GitHub Pages / Vercel / Netlify, the arcade will be live at:
   ```
   https://plumbmonkey.online/arcade/
   ```

### Local test
```bash
# From this folder
npx serve .
# or open index.html with Live Server
```

## Controls summary

- **Revenger**: Arrow/WASD move · Space/Z fire  
- **Food Fight**: WASD move · Mouse aim · Click/Space throw  
- **Robotron**: WASD move · Mouse aim · Click/Space fire  
- **Skyline**: A/D move · Space/W flap  

## License
MIT · Built with ❤️ by William "Plumbmonkey" Henwood  
Part of the Ghost Circuit universe
